package com.nic.datapersistance.model

import java.text.DateFormat
import java.util.*


class Roll() {
    var rollName: String? = null
    var teamName: String? = null
    var playerName: String? = null
    var timeAssigned: Long? = null
    var id: Int? = null

    constructor(rollName: String, teamName: String, playerName: String, timeAssigned: Long, id: Int): this() {

        this.rollName = rollName
        this.teamName = teamName
        this.playerName = playerName
        this.timeAssigned = timeAssigned
        this.id = id

    }


    fun showHumanDate(timeAssigned: Long): String {


        var dateFormat: java.text.DateFormat = DateFormat.getDateInstance()
        var formattedDate: String = dateFormat.format(Date(timeAssigned).time)



        return "Created: ${formattedDate}"
    }


}