package com.nic.datapersistance.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import com.nic.datapersistance.R
import com.nic.datapersistance.data.rollListAdapter
import com.nic.datapersistance.data.rollsDataBaseHandler
import com.nic.datapersistance.model.Roll
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.activity_roll_list.*
import kotlinx.android.synthetic.main.popup.view.*

class rollListActivity : AppCompatActivity() {

    private var adapter: rollListAdapter? = null
    private var rollList: ArrayList<Roll>? = null
    private var layoutManager: RecyclerView.LayoutManager? = null
    private var rollListItems: ArrayList<Roll>? = null
    private var dialogBuilder: AlertDialog.Builder? = null
    private var dialog: AlertDialog? = null

    var dbHandler: rollsDataBaseHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_roll_list)

        rollList = ArrayList<Roll>()
        layoutManager = LinearLayoutManager(this)
        adapter = rollListAdapter(rollListItems!!, this)
        dbHandler = rollsDataBaseHandler(this)



        recyclerViewId.layoutManager = layoutManager
        recyclerViewId.adapter = adapter


        rollList = dbHandler!!.readRoll()
        rollList!!.reverse()


        for (r in rollList!!.iterator()) {

            val roll = Roll()

            roll.rollName = "Role: ${r.rollName}"
            roll.playerName = "Player Name: ${r.playerName}"
            roll.teamName = "Team Name: ${r.teamName}"
            roll.id = r.id
            roll.showHumanDate(r.timeAssigned!!)



            rollListItems!!.add(roll)


        }


        adapter!!.notifyDataSetChanged()


       // for (r in rollList){


            //Log.d('List', r.enterRollName)
        //}


    }





    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.top_menu, menu)

        return true
    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {


        if (item!!.itemId == R.id.add_menu_button) {

            Log.d("Item Clicked", "Item Clickedc")

            createPopupDialog()

        }

        return super.onOptionsItemSelected(item)

    }


    fun createPopupDialog() {



        var view = layoutInflater.inflate(R.layout.popup, null)
        var rollName = view.popEnterRoll
        var teamName = view.popEnterTeamName
        var playerName = view.popEnterPlayerName
        var saveButton = view.popSaveRoll

        dialogBuilder = AlertDialog.Builder(this).setView(view)
        dialog = dialogBuilder!!.create()
        dialog?.show()

        saveButton.setOnClickListener {

            var name = rollName.text.toString().trim()
            var tName = teamName.text.toString().trim()
            var pName = playerName.text.toString().trim()

            if (!TextUtils.isEmpty(name)
                && !TextUtils.isEmpty(tName)
                && !TextUtils.isEmpty(pName)) {


                var roll = Roll()
                roll.rollName = name
                roll.teamName = tName
                roll.playerName = pName

                dbHandler!!.createRoll(roll)

                dialog!!.dismiss()

                startActivity(Intent(this, rollListActivity::class.java))
                finish()

            }else {

            }
        }


    }

}
