package com.nic.datapersistance.data

import android.content.Context
import android.content.Intent
import android.support.v7.app.AlertDialog
import android.support.v7.view.menu.ActionMenuItemView
import android.support.v7.view.menu.MenuView
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.nic.datapersistance.R
import com.nic.datapersistance.activity.rollListActivity
import com.nic.datapersistance.model.Roll
import kotlinx.android.synthetic.main.popup.view.*

class rollListAdapter(private val list: ArrayList<Roll>,
                      private val context: Context): RecyclerView.Adapter<rollListAdapter.ViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {

        val view = LayoutInflater.from(context)
            .inflate(R.layout.list_row, parent, false)

        return ViewHolder(view, context,list)

    }

    override fun getItemCount(): Int {

        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {


        holder?.bindViews(list[position])
    }



    inner class ViewHolder(itemView: View, context: Context, list: ArrayList<Roll>): RecyclerView.ViewHolder(itemView), View.OnClickListener{

        var mContext = context
        var mList = list

        var rollName = itemView.findViewById(R.id.listRollName) as TextView
        var playerName = itemView.findViewById(R.id.listPlayerName) as TextView
        var assignedDate = itemView.findViewById(R.id.listDate) as TextView
        var deleteButton = itemView.findViewById(R.id.listDeleteButton) as Button
        var editButton = itemView.findViewById(R.id.listEditButton) as Button






        fun bindViews(roll: Roll) {

            rollName.text = roll.rollName
            playerName.text = roll.playerName
            assignedDate.text = roll.showHumanDate(System.currentTimeMillis())

            deleteButton.setOnClickListener(this)
            editButton.setOnClickListener(this)


        }


        override fun onClick(v: View?) {


            var mPosition: Int = adapterPosition
            var roll = mList[mPosition]

            when(v!!.id) {



                deleteButton.id -> { deleteRoll(roll.id!!)
                    mList.removeAt(adapterPosition)
                    notifyItemRemoved(adapterPosition)
                }
                editButton.id -> {

                    editRoll(roll)


                }

            }

        }

        fun deleteRoll(id: Int) {

            var db: rollsDataBaseHandler = rollsDataBaseHandler(mContext)

            db.deleteRoll(id)

        }


        fun editRoll(roll: Roll) {



            var dialogBuilder: AlertDialog.Builder? = null
            var dialog: AlertDialog?
            var dbHandler: rollsDataBaseHandler = rollsDataBaseHandler(context)

            var view = LayoutInflater.from(context).inflate(R.layout.popup, null)
            var rollName = view.popEnterRoll
            var teamName = view.popEnterTeamName
            var playerName = view.popEnterPlayerName
            var saveButton = view.popSaveRoll

            dialogBuilder = AlertDialog.Builder(context).setView(view)
            dialog = dialogBuilder!!.create()
            dialog?.show()

            saveButton.setOnClickListener {

                var name = rollName.text.toString().trim()
                var tName = teamName.text.toString().trim()
                var pName = playerName.text.toString().trim()

                if (!TextUtils.isEmpty(name)
                    && !TextUtils.isEmpty(tName)
                    && !TextUtils.isEmpty(pName)) {


                    //var roll = Roll()
                    roll.rollName = name
                    roll.teamName = tName
                    roll.playerName = pName

                    dbHandler!!.updateRoll(roll)
                    notifyItemChanged(adapterPosition, roll)

                    dialog!!.dismiss()

                    //startActivity(Intent(this, rollListActivity::class.java))
                    //finish()

                }else {

                }
            }

        }
    }
}