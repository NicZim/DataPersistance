package com.nic.datapersistance.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.nic.datapersistance.model.*
import java.text.DateFormat
import java.util.*
import kotlin.collections.ArrayList

class rollsDataBaseHandler(context: Context) :
        SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {


    override fun onCreate(db: SQLiteDatabase?) {

        var CREATE_ROLL_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + KEY_ID + " INTEGER PRIMARY KEY," +
                                 KEY_ROLL_NAME + " TEXT," + KEY_ROLL_TEAM_NAME + " TEXT," + KEY_ROLL_PLAYER_NAME + " TEXT," +
                                 KEY_ROLL_ASSIGNED_TIME + " LONG" + " );"


        db?.execSQL(CREATE_ROLL_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

        db?.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)


        onCreate(db)


    }

    fun createRoll(roll: Roll) {
        var db: SQLiteDatabase = writableDatabase

        var values: ContentValues = ContentValues()
        values.put(KEY_ROLL_NAME, roll.rollName)
        values.put(KEY_ROLL_TEAM_NAME, roll.teamName)
        values.put(KEY_ROLL_PLAYER_NAME, roll.playerName)
        values.put(KEY_ROLL_ASSIGNED_TIME, System.currentTimeMillis())

        db.insert(TABLE_NAME, null, values)

        Log.d("DATA INSERTED", "SUCCESS")
        db.close()


    }

    fun readARoll(id: Int): Roll {

        var db:SQLiteDatabase = writableDatabase



        var cursor: Cursor = db.query(TABLE_NAME, arrayOf(KEY_ID, KEY_ROLL_NAME, KEY_ROLL_TEAM_NAME, KEY_ROLL_PLAYER_NAME, KEY_ROLL_ASSIGNED_TIME),
                    KEY_ID + "=?", arrayOf(id.toString()), null, null, null, null)



        if (cursor != null)
            cursor.moveToFirst()

            var roll = Roll()

            roll.id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
            roll.rollName = cursor.getString(cursor.getColumnIndex(KEY_ROLL_NAME))
            roll.teamName = cursor.getString(cursor.getColumnIndex(KEY_ROLL_TEAM_NAME))
            roll.playerName = cursor.getString(cursor.getColumnIndex(KEY_ROLL_PLAYER_NAME))
            roll.timeAssigned = cursor.getLong(cursor.getColumnIndex(KEY_ROLL_ASSIGNED_TIME))

            return roll


        //var dateFormat: java.text.DateFormat = DateFormat.getDateInstance()
        //var formattedDate = dateFormat.format(Date(cursor.getLong(cursor.getColumnIndex(KEY_ROLL_ASSIGNED_TIME))).time)




    }
    fun readRoll(): ArrayList<Roll> {


        var db: SQLiteDatabase = readableDatabase
        var list: ArrayList<Roll> = ArrayList()

        //Select all chores from table
        var selectAll = "SELECT * FROM " + TABLE_NAME

        var cursor: Cursor = db.rawQuery(selectAll, null)

        //loop through our chores
        if (cursor.moveToFirst()) {
            do {
                var roll = Roll()

                roll.id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                roll.rollName = cursor.getString(cursor.getColumnIndex(KEY_ROLL_NAME))
                roll.teamName = cursor.getString(cursor.getColumnIndex(KEY_ROLL_TEAM_NAME))
                roll.playerName = cursor.getString(cursor.getColumnIndex(KEY_ROLL_PLAYER_NAME))
                roll.timeAssigned = cursor.getLong(cursor.getColumnIndex(KEY_ROLL_ASSIGNED_TIME))

                list.add(roll)

            } while (cursor.moveToNext())
        }


        return list

    }


    fun updateRoll(roll: Roll): Int {

        var db: SQLiteDatabase = writableDatabase

        var values: ContentValues = ContentValues()
        values.put(KEY_ROLL_NAME, roll.rollName)
        values.put(KEY_ROLL_TEAM_NAME, roll.teamName)
        values.put(KEY_ROLL_PLAYER_NAME, roll.playerName)
        values.put(KEY_ROLL_ASSIGNED_TIME, System.currentTimeMillis())

        return db.update(TABLE_NAME, values, KEY_ID + "=?", arrayOf(roll.id.toString()))

    }

    fun deleteRoll(id: Int) {

        var db:SQLiteDatabase = writableDatabase
        db.delete(TABLE_NAME, KEY_ID + "=?", arrayOf(id.toString()))

        db.close()

    }

    fun getRollCount(): Int {

        var db: SQLiteDatabase = readableDatabase
        var countQuery = "SELECT * FROM " + TABLE_NAME
        var cursor: Cursor = db.rawQuery(countQuery, null)

        return cursor.count




    }


}