package com.nic.datapersistance.activity

import android.app.ProgressDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.nic.datapersistance.R
import com.nic.datapersistance.data.rollListAdapter
import com.nic.datapersistance.data.rollsDataBaseHandler
import com.nic.datapersistance.model.Roll
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.activity_roll_list.*

class MainActivity : AppCompatActivity() {

    var dbHandler: rollsDataBaseHandler? = null
    var progressDialog: ProgressDialog? = null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHandler = rollsDataBaseHandler(this)
        progressDialog = ProgressDialog(this)


        checkDB()


        saveInfo.setOnClickListener {
            progressDialog!!.setMessage("Saving...")
            progressDialog!!.show()

            if (!TextUtils.isEmpty(enterRollName.text.toString())
                && !TextUtils.isEmpty(enterTeamName.text.toString())
                && !TextUtils.isEmpty(enterPlayerName.text.toString())) {


                var roll = Roll()
                roll.rollName = enterRollName.text.toString()
                roll.teamName = enterTeamName.text.toString()
                roll.playerName = enterPlayerName.text.toString()




                saveToDB(roll)
                progressDialog!!.cancel()
                startActivity(Intent (this, rollListActivity::class.java))

            }else {
                Toast.makeText(this, "Please enter a chore", Toast.LENGTH_LONG).show()
            }



        }




    }


    fun checkDB() {

        if (dbHandler!!.getRollCount() > 0) {

            startActivity(Intent(this, rollListActivity::class.java))

        }

    }



    fun saveToDB(roll: Roll){

        dbHandler!!.createRoll(roll)



    }


}
