package com.nic.datapersistance.model

    val DATABASE_VERSION: Int = 1
    val DATABASE_NAME: String = "roll.db"
    val TABLE_NAME: String = "rolls"

    val KEY_ID: String = "id"
    val KEY_ROLL_NAME: String = "roll_name"
    val KEY_ROLL_TEAM_NAME: String = "roll_team_name"
    val KEY_ROLL_PLAYER_NAME: String = "roll_player_name"
    val KEY_ROLL_ASSIGNED_TIME: String = "roll_assigned_time"
